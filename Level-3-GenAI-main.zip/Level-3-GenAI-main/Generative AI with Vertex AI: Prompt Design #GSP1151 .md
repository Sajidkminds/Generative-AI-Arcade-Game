# GSP1151
>🚨 [PLEASE SUBSCRIBE OUR CHANNEL CLOUDHUSTLER](https://www.youtube.com/@cloudhustlers) **&** [JOIN OUR COMMUNITY](https://chat.whatsapp.com/KBfUcSleGGEFf2Xvvm8FW3)
```cmd
https://console.cloud.google.com/vertex-ai/workbench/user-managed?
```
### Open JupyterLab
### Generative-ai > Language > prompts > intro_prompt_design.ipynb (Run each cell one at a time)
### examples > ideation.ipynb
